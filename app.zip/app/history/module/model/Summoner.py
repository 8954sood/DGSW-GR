from pydantic import BaseModel
class Summoner(BaseModel):
    name: str